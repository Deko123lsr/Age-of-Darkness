# ⚔️ 1490 DC — Reinos em Guerra

Jogo multiplayer online de estratégia. O dono da sala configura os países, ano inicial, IA, diplomacia e guerras. Os jogadores entram por um código e escolhem seus países.

## Rodar no computador

Requer Node.js 18+.

```bash
npm install
npm start
```

Depois abra `http://localhost:3000`.

## Colocar online

O GitHub pode guardar o código e o frontend, mas **GitHub Pages não executa o servidor WebSocket**. Para multiplayer real, publique este projeto em um serviço que execute Node.js, como Render, Railway ou Fly.io.

Configuração:
- Build/Install: `npm install`
- Start: `npm start`
- Porta: use a variável `PORT` fornecida pelo serviço.

O mesmo projeto já serve o frontend e o WebSocket, então basta uma URL pública.

## Regras atuais

- O criador da sala é o dono.
- O dono configura ano, limite de jogadores, IA, diplomacia e guerras.
- O dono pode colocar países como IA ou disponibilizá-los.
- Jogadores escolhem países livres.
- Todos precisam marcar "Pronto" antes do dono iniciar.
- A partida sincroniza pelo WebSocket.
- O estado atual fica em memória no servidor; reiniciar o servidor encerra as salas.
- Esta base não usa banco de dados nem contas permanentes.
