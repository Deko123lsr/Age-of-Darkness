const express=require("express");
const http=require("http");
const {WebSocketServer}=require("ws");
const crypto=require("crypto");
const path=require("path");

const app=express(), server=http.createServer(app), wss=new WebSocketServer({server});
app.use(express.static(path.join(__dirname,"public")));
app.get("/health",(req,res)=>res.json({ok:true,game:"1490 DC"}));

const rooms=new Map();
const countries=[
["Portugal","🇵🇹"],["Espanha","🇪🇸"],["França","🇫🇷"],["Inglaterra","🏴"],
["Estados Italianos","🇮🇹"],["Império Otomano","☪️"],["Polônia","🇵🇱"],
["Marrocos","🇲🇦"],["Áustria","🇦🇹"],["Holanda","🇳🇱"],["Dinamarca","🇩🇰"],["Suécia","🇸🇪"]
];

function code(){return crypto.randomBytes(3).toString("hex").toUpperCase();}
function send(ws,type,data={}){if(ws.readyState===1)ws.send(JSON.stringify({type,...data}));}
function broadcast(room,type,data={}){for(const p of room.players)send(p.ws,type,data);}
function publicRoom(room){
 return {code:room.code,host:room.host,settings:room.settings,
 players:room.players.map(p=>({id:p.id,name:p.name,country:p.country,ready:p.ready,host:p.id===room.host})),
 countries:room.countryConfig};
}
function roomState(room){return {room:publicRoom(room)};}

wss.on("connection",ws=>{
 let player=null,room=null;
 ws.on("message",raw=>{
  let m; try{m=JSON.parse(raw)}catch{return}
  if(m.type==="create"){
   const c=code();
   room={code:c,host:"",players:[],started:false,settings:{year:1490,maxPlayers:8,ai:true,diplomacy:true,wars:true},countryConfig:{}};
   countries.forEach(([name,flag])=>room.countryConfig[name]={name,flag,owner:null,ai:true,difficulty:"Normal",gold:700,army:100,population:1000,research:80});
   rooms.set(c,room);
   player={id:crypto.randomUUID(),name:String(m.name||"Governante").slice(0,24),country:null,ready:false,ws};
   room.host=player.id;room.players.push(player);room=room;
   send(ws,"created",{code:c});broadcast(room,"state",roomState(room));return;
  }
  if(m.type==="join"){
   room=rooms.get(String(m.code||"").toUpperCase());
   if(!room)return send(ws,"error",{message:"Sala não encontrada."});
   if(room.started)return send(ws,"error",{message:"A partida já começou."});
   if(room.players.length>=room.settings.maxPlayers)return send(ws,"error",{message:"Sala cheia."});
   player={id:crypto.randomUUID(),name:String(m.name||"Jogador").slice(0,24),country:null,ready:false,ws};
   room.players.push(player);send(ws,"joined",{code:room.code});broadcast(room,"state",roomState(room));return;
  }
  if(!room||!player)return;
  if(m.type==="chooseCountry"){
   const name=String(m.country||"");
   const cfg=room.countryConfig[name];
   if(!cfg)return;
   if(cfg.owner && cfg.owner!==player.id)return send(ws,"error",{message:"Esse país já foi escolhido."});
   if(player.country)room.countryConfig[player.country].owner=null;
   player.country=name;cfg.owner=player.id;cfg.ai=false;player.ready=false;
   broadcast(room,"state",roomState(room));return;
  }
  if(m.type==="setCountry" && player.id===room.host){
   const cfg=room.countryConfig[m.country]; if(!cfg)return;
   const allowed=["ai","difficulty","gold","army","population","research"];
   if(allowed.includes(m.field)){
    cfg[m.field]=m.field==="difficulty"?String(m.value):m.field==="ai"?!!m.value:Math.max(0,Number(m.value)||0);
    if(m.field==="ai")cfg.owner=null;
   }
   broadcast(room,"state",roomState(room));return;
  }
  if(m.type==="settings" && player.id===room.host){
   for(const k of ["year","maxPlayers","ai","diplomacy","wars"])if(k in m)room.settings[k]=k==="year"||k==="maxPlayers"?Math.max(1,Number(m[k])||1490):!!m[k];
   broadcast(room,"state",roomState(room));return;
  }
  if(m.type==="kick" && player.id===room.host){
   const target=room.players.find(p=>p.id===m.id);if(target&&target.id!==room.host){send(target.ws,"kicked");target.ws.close();room.players=room.players.filter(p=>p!==target);broadcast(room,"state",roomState(room));}
   return;
  }
  if(m.type==="ready"){
   if(!player.country)return send(ws,"error",{message:"Escolha um país primeiro."});
   player.ready=!player.ready;broadcast(room,"state",roomState(room));return;
  }
  if(m.type==="start" && player.id===room.host){
   if(!room.players.every(p=>p.country&&p.ready))return send(ws,"error",{message:"Todos os jogadores precisam escolher um país e marcar pronto."});
   room.started=true;
   room.game={year:room.settings.year,gold:500,food:300,wood:300,iron:200,log:["A partida começou em "+room.settings.year+"."]};
   broadcast(room,"started",{game:room.game,room:publicRoom(room)});return;
  }
  if(m.type==="gameAction" && room.started){
   const g=room.game;
   if(m.action==="nextYear"){g.year++;g.gold+=50;g.food+=35;g.wood+=20;g.iron+=10;g.log.unshift("Ano "+g.year+": o reino produziu recursos.");}
   if(m.action==="trade"&&g.food>=50){g.food-=50;g.gold+=80;g.log.unshift("Comércio: +80 ouro.");}
   if(m.action==="recruit"&&g.gold>=60&&g.food>=20){g.gold-=60;g.food-=20;g.army=(g.army||100)+20;g.log.unshift("Recrutamento: +20 soldados.");}
   if(m.action==="research"&&g.research>=30){g.research-=30;g.log.unshift("Pesquisa concluída.");}
   broadcast(room,"gameState",{game:g});return;
  }
 });
 ws.on("close",()=>{
  if(!room||!player)return;
  room.players=room.players.filter(p=>p!==player);
  if(player.id===room.host){
   if(room.players.length){room.host=room.players[0].id}
   else{rooms.delete(room.code);return}
  }
  broadcast(room,"state",roomState(room));
 });
});
const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log("1490 DC online na porta "+PORT));